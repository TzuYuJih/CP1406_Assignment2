<html>
<head><link href="style.css" rel="stylesheet" type="text/css" /></head>
<body>
<div class="center">
<h2>Thank you for signing up for the Petite Treats Weekly newsletter.</h2>
<h2>We have added the following information to our files regarding your interests:</h2>
<h3>
Name: <?php echo $_POST["name"]; ?><br>
Email: <?php echo $_POST["email"]; ?><br>
<?php   	  $str = " ";
        	  if ((isset($_POST["interestFood1"])) || (isset($_POST["interestFood2"])))
                      $str.= "Product interests: ";
		  if (isset($_POST["interestFood1"]))
			$str.= $_POST["interestFood1"].= " ";
                  if (isset($_POST["interestFood2"]))
                      $str.= $_POST["interestFood2"];
				  if (isset($_POST["interestFood3"]))
                      $str.= $_POST["interestFood3"];
				  if (isset($_POST["interestFood4"]))
                      $str.= $_POST["interestFood4"];
				  if (isset($_POST["interestFood5"]))
                      $str.= $_POST["interestFood5"];
				  if (isset($_POST["interestFood6"]))
                      $str.= $_POST["interestFood6"];
                  echo $str;    ?><br>
				Birth Day: <?php echo $_POST["birthDay"]; ?><br>
				Birth Month: <?php echo $_POST["birthMonth"]; ?><br>
				 
</h3>
</div>
</body>
</html>